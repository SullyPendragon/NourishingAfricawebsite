'use client';
import { useState } from 'react';

export default function Donate(){
const [amount,setAmount]=useState('');

return(
<div className="container">
<h1>Donate</h1>

<input placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} />

<h3>Paystack / Stripe (to integrate)</h3>
<button className="btn">Donate {amount}</button>

<h3>Crypto</h3>
<p>BTC: xxx</p>
<p>ETH: xxx</p>

</div>
)}