export async function POST(req){
return Response.json({status:"success"});
}