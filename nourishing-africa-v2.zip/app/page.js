export default function Home(){
return(
<div>
<section className="hero">
<h1>A child is hungry right now.</h1>
<p>You can change that today.</p>
<a href="/donate"><button className="btn">Feed Someone Now</button></a>
</section>

<div className="container">
<h2>Live Impact</h2>
<div className="grid grid-3">
<div className="card"><h3>Meals Served</h3><p>1,245</p></div>
<div className="card"><h3>Donations</h3><p>$12,300</p></div>
<div className="card"><h3>People Reached</h3><p>870</p></div>
</div>

<h2>Why Transparency Matters</h2>
<p>Every naira and dollar is tracked publicly so you see exactly where your money goes.</p>
</div>
</div>
)}